package com.example.gmstoggle

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.inputmethod.InputMethodManager

class GmsToggleService : AccessibilityService() {

    private val games = setOf(
        "com.tencent.ig", "com.pubg.imobile", "com.pubg.krmobile",
        "com.vng.pubgmobile", "com.rekoo.pubgm"
    )
    private val gms = "com.google.android.gms"
    private val settingsPkg = "com.android.settings"

    private val disableTexts = listOf("Disable", "تعطيل")
    private val enableTexts = listOf("Enable", "تفعيل", "تمكين")
    private val confirmTexts = listOf("Disable", "Disable app", "تعطيل", "OK", "موافق")

    private enum class State { IDLE, DISABLING, GAME_LAUNCH, CHECKING, ENABLING }

    private var state = State.IDLE
    private var stateSince = 0L
    private var clicks = 0
    private var lastClick = 0L
    private var checkPending = false
    private var lastAttempt = 0L
    private var lastPkg = ""
    private var launcherPkg: String? = null
    private var ignored = setOf<String>()
    private val handler = Handler(Looper.getMainLooper())

    private val prefs by lazy { getSharedPreferences("prefs", MODE_PRIVATE) }

    private var disabledByUs: Boolean
        get() = prefs.getBoolean("disabled", false)
        set(v) { prefs.edit().putBoolean("disabled", v).apply() }

    private var currentGame: String
        get() = prefs.getString("game", "com.tencent.ig") ?: "com.tencent.ig"
        set(v) { prefs.edit().putString("game", v).apply() }

    // بعد كام ثانية من خروجك من اللعبة يتأكد إنها اتقفلت (بيتغير من التطبيق)
    private fun delayMs() = prefs.getLong("delay_sec", 120L) * 1000L

    // الحالة الحقيقية لخدمات جوجل (مش بس اللي احنا فاكرينه)
    private fun isGmsEnabled(): Boolean = try {
        packageManager.getApplicationInfo(gms, 0).enabled
    } catch (e: Exception) { true }

    private fun setState(s: State) {
        state = s
        stateSince = System.currentTimeMillis()
    }

    override fun onServiceConnected() {
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        launcherPkg = packageManager.resolveActivity(home, 0)?.activityInfo?.packageName
        val imes = (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .enabledInputMethodList.map { it.packageName }
        ignored = imes.toSet() + setOf("com.android.systemui", packageName, settingsPkg)
        if (disabledByUs) {
            if (isGmsEnabled()) disabledByUs = false else scheduleCheck()
        }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return

        // لو اتعلق في أي خطوة أكتر من 20 ثانية نرجع للوضع الطبيعي
        if (state != State.IDLE && System.currentTimeMillis() - stateSince > 20_000) {
            if (state == State.ENABLING) disabledByUs = false // غالباً متفعّلة أصلاً
            setState(State.IDLE)
        }
        if (pkg !in ignored) lastPkg = pkg

        when (state) {
            State.IDLE -> {
                if (pkg in games) {
                    cancelCheck()
                    if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                        currentGame = pkg
                        if (isGmsEnabled()) {
                            // خدمات جوجل شغالة فعلاً: عطّلها (مرة كل دقيقة كحد أقصى لو فشلت)
                            if (System.currentTimeMillis() - lastAttempt > 60_000) {
                                lastAttempt = System.currentTimeMillis()
                                disabledByUs = false
                                clicks = 0
                                setState(State.DISABLING)
                                openGmsPage()
                            }
                        } else {
                            disabledByUs = true // معطّلة أصلاً، هنفعّلها بعد قفل اللعبة
                        }
                    }
                } else if (disabledByUs && !checkPending && pkg !in ignored) {
                    scheduleCheck()
                }
            }

            State.DISABLING -> if (pkg == settingsPkg) {
                val root = rootInActiveWindow ?: return
                if (System.currentTimeMillis() - lastClick < 700) return
                val list = if (clicks == 0) disableTexts else confirmTexts
                if (clickByText(root, list)) {
                    lastClick = System.currentTimeMillis()
                    clicks++
                    if (clicks >= 2) {
                        disabledByUs = true
                        setState(State.GAME_LAUNCH)
                        handler.postDelayed({ leaveSettings() }, 800)
                    }
                }
            }

            State.GAME_LAUNCH -> if (pkg in games) setState(State.IDLE)

            State.CHECKING -> {}

            State.ENABLING -> if (pkg == settingsPkg) {
                val root = rootInActiveWindow ?: return
                if (System.currentTimeMillis() - lastClick < 700) return
                if (clickByText(root, enableTexts)) {
                    lastClick = System.currentTimeMillis()
                    disabledByUs = false
                    setState(State.IDLE)
                    handler.postDelayed({ performGlobalAction(GLOBAL_ACTION_BACK) }, 800)
                }
            }
        }
    }

    // الخروج من الإعدادات والرجوع للعبة
    private fun leaveSettings() {
        val i = packageManager.getLaunchIntentForPackage(currentGame)
        if (i != null) startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        else performGlobalAction(GLOBAL_ACTION_BACK)
        handler.postDelayed({ if (state == State.GAME_LAUNCH) setState(State.IDLE) }, 4000)
    }

    // ===== التأكد إن اللعبة اتقفلت (عن طريق شاشة التطبيقات الأخيرة) =====
    private val checkRunnable = Runnable { runCheck() }

    private fun scheduleCheck() {
        checkPending = true
        handler.removeCallbacks(checkRunnable)
        handler.postDelayed(checkRunnable, delayMs())
    }

    private fun cancelCheck() {
        checkPending = false
        handler.removeCallbacks(checkRunnable)
    }

    private fun runCheck() {
        checkPending = false
        if (!disabledByUs) return
        if (isGmsEnabled()) { disabledByUs = false; return } // اتفعّلت بالفعل
        if (state != State.IDLE) { scheduleCheck(); return }
        if (lastPkg in games) return // اللعبة قدامك دلوقتي
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isInteractive) { scheduleCheck(); return } // الشاشة مقفولة
        setState(State.CHECKING)
        performGlobalAction(GLOBAL_ACTION_RECENTS)
        handler.postDelayed({ readRecents() }, 1500)
    }

    private fun gameNames(): List<String> {
        val l = mutableListOf<String>()
        try {
            l += packageManager.getApplicationLabel(packageManager.getApplicationInfo(currentGame, 0)).toString()
        } catch (_: Exception) {}
        l += listOf("PUBG", "BGMI", "Battlegrounds")
        return l
    }

    private fun readRecents() {
        val root = rootInActiveWindow
        val p = root?.packageName?.toString()
        val onRecents = root != null && (p == launcherPkg || p == "com.android.systemui")
        if (!onRecents) {
            // مفتحتش الريسنتس بنجاح، منحكمش
            setState(State.IDLE)
            scheduleCheck()
            return
        }
        val found = gameNames().any { root!!.findAccessibilityNodeInfosByText(it).isNotEmpty() }
        performGlobalAction(GLOBAL_ACTION_BACK) // خروج من الريسنتس
        if (found) {
            setState(State.IDLE)
            scheduleCheck() // اللعبة لسه في الخلفية
        } else {
            // اللعبة مقفولة: فعّل خدمات جوجل
            handler.postDelayed({
                setState(State.ENABLING)
                openGmsPage()
            }, 700)
        }
    }

    private fun openGmsPage() {
        startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$gms"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    private fun clickByText(root: AccessibilityNodeInfo, texts: List<String>): Boolean {
        for (t in texts) {
            for (node in root.findAccessibilityNodeInfosByText(t)) {
                if (!node.isEnabled) continue
                var n: AccessibilityNodeInfo? = node
                while (n != null && !n.isClickable) n = n.parent
                if (n?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true) return true
            }
        }
        return false
    }

    override fun onInterrupt() {}
}
