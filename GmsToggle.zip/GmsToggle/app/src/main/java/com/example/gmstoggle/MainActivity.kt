package com.example.gmstoggle

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("prefs", MODE_PRIVATE)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        fun label(t: String) = TextView(this).apply { text = t; textSize = 16f; setPadding(0, 24, 0, 8) }

        layout.addView(label("1) فعّل الخدمة: إمكانية الوصول > التطبيقات المثبتة > GMS Toggle"))
        layout.addView(Button(this).apply {
            text = "فتح إعدادات إمكانية الوصول"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        layout.addView(label("2) بعد كام ثانية من خروجك من اللعبة يتأكد إنها اتقفلت (بيفتح الريسنتس لحظة) ويفعّل خدمات جوجل:"))
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(prefs.getLong("delay_sec", 120L).toString())
        }
        layout.addView(input)
        layout.addView(Button(this).apply {
            text = "حفظ"
            setOnClickListener {
                val v = input.text.toString().toLongOrNull()
                if (v == null || v < 10) {
                    Toast.makeText(context, "اكتب رقم 10 أو أكتر", Toast.LENGTH_SHORT).show()
                } else {
                    prefs.edit().putLong("delay_sec", v).apply()
                    Toast.makeText(context, "تم الحفظ: $v ثانية", Toast.LENGTH_SHORT).show()
                }
            }
        })

        layout.addView(label("لو حصلت مشكلة:"))
        layout.addView(Button(this).apply {
            text = "فتح صفحة Google Play services"
            setOnClickListener {
                prefs.edit().putBoolean("disabled", false).apply()
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:com.google.android.gms"))
                )
            }
        })
        setContentView(layout)
    }
}
