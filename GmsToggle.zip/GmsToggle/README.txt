بناء الـ APK بدون كمبيوتر:
1) اعمل حساب على github.com واعمل Repository جديد
2) ارفع كل محتويات الفولدر ده (لازم .github يترفع كمان)
3) افتح تبويب Actions > Build APK > Run workflow
4) بعد دقيقتين نزّل GmsToggle-apk من Artifacts وثبّت app-debug.apk
